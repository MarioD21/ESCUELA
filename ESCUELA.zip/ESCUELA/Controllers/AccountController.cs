﻿using ESCUELA.Data;
using ESCUELA.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace ESCUELA.Controllers
{
    public class AccountController : Controller
    {
        private readonly EscuelaContext _context;

        public AccountController(EscuelaContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View(new LoginViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;

            if (!ModelState.IsValid)
                return View(model);

            var docente = await _context.Docentes
                .FirstOrDefaultAsync(d => d.Usuario == model.Usuario);

            if (docente == null || docente.Contrasena != model.Contrasena)
            {
                ModelState.AddModelError(string.Empty, "Usuario o contraseña incorrectos");
                return View(model);
            }

            if (!docente.Estatus)
            {
                ModelState.AddModelError(string.Empty, "El usuario se encuentra inactivo");
                return View(model);
            }

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, docente.Usuario),
                new Claim(ClaimTypes.NameIdentifier, docente.Id_docente.ToString()),
                new Claim("NombreCompleto", $"{docente.Nombre} {docente.ApellidoPaterno} {docente.ApellidoMaterno}")
            };

            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity),
                new AuthenticationProperties
                {
                    IsPersistent = model.RememberMe,
                    ExpiresUtc = DateTimeOffset.UtcNow.AddHours(8)
                });

            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View(new RegisterViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var usuarioExistente = await _context.Docentes
                .AnyAsync(d => d.Usuario == model.Usuario);

            if (usuarioExistente)
            {
                ModelState.AddModelError(nameof(model.Usuario), "Ese usuario ya está registrado");
                return View(model);
            }

            var docente = new Docente
            {
                Numero_Empleado = model.Numero_Empleado,
                Nombre = model.Nombre,
                ApellidoPaterno = model.ApellidoPaterno,
                ApellidoMaterno = model.ApellidoMaterno,
                Correo = model.Correo,
                Usuario = model.Usuario,
                Contrasena = model.Contrasena,
                Estatus = true
            };

            _context.Docentes.Add(docente);
            await _context.SaveChangesAsync();

            TempData["RegistroExitoso"] = "Cuenta creada correctamente. Ya puedes iniciar sesión.";
            return RedirectToAction("Login");
        }

        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }
    }
}
