﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ESCUELA.Migrations
{
    /// <inheritdoc />
    public partial class Inicialcrear_docente : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
